﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TestWebAPI.Models;

namespace TestWebAPI.BusinessLayer
{
   public interface ICreditCardValidatorBusinessLayer
    {
        bool IsValidCreditcard(string cardNumber);
    }
}
