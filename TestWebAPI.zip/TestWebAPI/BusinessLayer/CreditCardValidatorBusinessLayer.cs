﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using TestWebAPI.Common;
using TestWebAPI.Models;
using TestWebAPI.DataAccessLayer;


namespace TestWebAPI.BusinessLayer
{
    public class CreditCardValidatorBusinessLayer : ICreditCardValidatorBusinessLayer
    {
        private ICreditCardValidatorDataAccessLayer objCreditCardValidatorDA;
        public CreditCardValidatorBusinessLayer(ICreditCardValidatorDataAccessLayer _obj)
        {
            objCreditCardValidatorDA = _obj;
        }

        public bool IsValidCreditcard(string cardNumber)
        {
            return objCreditCardValidatorDA.IsValidCreditcard(cardNumber);
        }
    }
}