﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace TestWebAPI.Models
{
    public class CreditCard
    {
        public int MyProperty { get; set; }
    }
}