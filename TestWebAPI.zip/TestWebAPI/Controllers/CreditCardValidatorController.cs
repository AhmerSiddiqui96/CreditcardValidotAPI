﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using TestWebAPI.BusinessLayer;

namespace TestWebAPI.Controllers
{
    public class CreditCardValidatorController : ApiController
    {
        // GET: CreditCardValidator

        ICreditCardValidatorBusinessLayer _objBusinessLayer;


        public CreditCardValidatorController(ICreditCardValidatorBusinessLayer creditCardValidatorBusiness)
        {
            _objBusinessLayer = creditCardValidatorBusiness;
        }

        [HttpGet]
        [Route("api/CreditCardValidator/IsvalidCard/{cardNumber}")]
        public bool IsvalidCard(string cardNumber)
        {
            if (string.IsNullOrEmpty(cardNumber))
            {
                var response = new HttpResponseMessage(HttpStatusCode.BadRequest)
                {
                    Content = new StringContent(string.Format("Please provide card number")),
                    ReasonPhrase = "Please provide card number"
                };

                throw new HttpResponseException(response);
            }
            return _objBusinessLayer.IsValidCreditcard(cardNumber);
        }

    }
}