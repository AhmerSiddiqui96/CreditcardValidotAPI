﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using TestWebAPI.Common;
using TestWebAPI.Models;

namespace TestWebAPI.DataAccessLayer
{
    public class CreditCardValidatorDataAccessLayer : ICreditCardValidatorDataAccessLayer
    {
        public bool IsValidCreditcard(string cardNumber)
        {
            return Luhn.CheckLuhn(cardNumber);
        }
    }
}