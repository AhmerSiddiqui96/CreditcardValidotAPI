﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;


namespace TestWebAPI.Common
{
    public static class Luhn
    {
        private static readonly Func<char, int> CharToInt = c => c - '0';

        private static readonly Func<int, bool> IsEven = i => i % 2 == 0;

        private static readonly Func<int, int> DoubleDigit = i => (i * 2).ToString().ToCharArray().Select(CharToInt).Sum();

        /// <summary>
        /// Verify if the card number is valid.
        /// </summary>
        /// <param name="creditCardNumber"></param>
        /// <returns></returns>
        public static bool CheckLuhn(string creditCardNumber)
        {
            if (!ValidationHelper.IsAValidNumber(creditCardNumber))
                throw new ArgumentException("Invalid number. Just numbers and white spaces are accepted in the string.");

            var checkSum = creditCardNumber
                .RemoveWhiteSpace()
                .ToCharArray()
                .Select(CharToInt)
                .Reverse()
                .Select((digit, index) => IsEven(index + 1) ? DoubleDigit(digit) : digit)
                .Sum();

            return checkSum % 10 == 0;
        }

        public static string CreateCheckDigit(string number)
        {
            if (!ValidationHelper.IsAValidNumber(number))
                throw new ArgumentException("Invalid number. Just numbers and white spaces are accepted in the string.");

            var digitsSum = number
                .RemoveWhiteSpace()
                .ToCharArray()
                .Reverse()
                .Select(CharToInt)
                .Select((digit, index) => IsEven(index) ? DoubleDigit(digit) : digit)
                .Sum();

            digitsSum = digitsSum * 9;

            return digitsSum
                .ToString()
                .ToCharArray()
                .Last()
                .ToString();
        }

        public static string RemoveWhiteSpace(this string input)
        {
            return new string(input.ToCharArray()
                .Where(c => !char.IsWhiteSpace(c))
                .ToArray());
        }
    }
}