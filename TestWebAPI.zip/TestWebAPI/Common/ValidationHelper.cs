﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace TestWebAPI.Common
{
    internal static class ValidationHelper
    {
        public static bool IsAValidNumber(string number)
        {
            number = number.RemoveWhiteSpace();

            return (number
                .ToCharArray()
                .All(char.IsNumber) &&
                    !string.IsNullOrEmpty(number));
        }

       
    }
}